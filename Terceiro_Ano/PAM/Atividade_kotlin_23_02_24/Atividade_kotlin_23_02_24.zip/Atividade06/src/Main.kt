//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import kotlin.math.PI
fun main() {
    val area = retangulo(5.3, 10.5)
    val areaT = triangulo(23.00, 12.00)
    val Classe1 = ClassTrian(10.00, 10.00, 10.00)
    val Classe2 = ClassTrian(10.00, 9.00, 8.00)
    val Classe3 = ClassTrian(10.00, 10.00, 8.00)
    val AreaCirc = AreaCirc(23.33)
    val AreaLosango = Losango(12.33, 34.55)
    val AreaTrapezio = Trapezio(3.00, 4.00, 10.00)

    println("Área do retângulo: $area")
    println("Área do triângulo: $areaT")
    println("Classificação do triângulo: $Classe1")
    println("Classificação do triângulo: $Classe2")
    println("Classificação do triângulo: $Classe3")
    println("Área do circulo: $AreaCirc")
    println("Área do Losango: $AreaLosango")
    println("Área do Trapézio: $AreaTrapezio")
}

fun retangulo(l1: Double = 0.00, l2: Double = 0.00): Double{
    return l1 * l2
}
fun triangulo(Base: Double = 0.00, Altura: Double = 0.00): Double {
    return ((Base * Altura)/2)
}
fun ClassTrian(lado1: Double = 0.00, lado2: Double = 0.00, lado3: Double = 0.00): String{
    if(lado1 != lado2 && lado1 != lado3 && lado2 != lado3){
        return "Escaleno"
    }else if(lado1 == lado2 && lado3 == lado2){
        return "Equilátero"
    }else{
        return "Isóceles"
    }
}

fun AreaCirc(Raio: Double = 0.00):Double{
   return PI * Raio * Raio
}
fun Losango(diagonal1: Double = 0.00, diagonal2: Double = 0.00):Double{
    return (diagonal1*diagonal2)/2
}
fun Trapezio(Base1: Double = 0.00, Base2: Double = 0.00, Altura: Double = 0.00):Double{
    return ((Base1+Base2)*Altura)/2
}