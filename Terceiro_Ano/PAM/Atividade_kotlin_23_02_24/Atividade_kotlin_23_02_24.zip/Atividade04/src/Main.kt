//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
inline fun transacao(funcao: () -> Unit){
    println("Abrindo transação...")
    try{
        funcao()
    }finally {
        println("fechando transação")
    }
}
fun main(args: Array<String>){
    transacao {
        println("Executando sql1...")
        println("Executando sql2...")
        println("Executando sql3...")
    }
}